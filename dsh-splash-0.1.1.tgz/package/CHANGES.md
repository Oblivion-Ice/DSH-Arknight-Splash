# dsh-splash 0.1.0 — 本地改动记录

上游只发 `dist/`（没有 `src/`），所以这里的改动直接落在 `dist/host/index.js` 上，
`C:\Users\融冰\.dsh\profiles\desktop\node_modules\dsh-splash\dist\host\index.js` 与本目录
保持一致（同一个 sha256）。

## 2026-10-18 · 真透明启动画面

现象：`transparent: true` 时启动动画仍然盖住桌面壁纸（用户看到"还是不透明"），
但 DOM 侧所有层都已经透明（`html`/`body`/`#root`/覆盖层底板实测都是
`rgba(0, 0, 0, 0)`），窗口本身也是 `transparent: true`。

真因（在运行中的页面里逐层实测得到）：

1. **画布上下文是 `{ alpha: false }`** —— 后备存储不透明，`clearRect()` 清出来的是
   **纯黑**而不是透明。所以"让渲染器跳过整屏底色填充"这件事本身就是无效的：
   跳过了填充，清屏仍然留下不透明的黑。
   实测像素：改前画布中心 `10,10,14,255`，改后 `0,0,0,0`（透明处）。
2. **底板是两层叠加**：`rgba(11,11,14,surfaceAlpha)` 之后再叠一层
   `rgba(4,4,6,(1-surfaceAlpha)*0.95)`，合计约 99.5% 不透明。即使只调
   `--dsh-splash-surface-alpha` 也没用——第二层会把差额补回去。透到壁纸上时它
   就是一块漆黑的矩形。

改动：

- `getContext("2d",{alpha:!1})` → `{alpha:!0}`（任何模式下外观不变：不透明模式下
  底板本身不透明）。
- 透明模式：底板压到 `0.32` 的浅色蒙版，并跳过第二层加深，
  让壁纸透出来、状态文字仍然可读。注意 clamp 必须写在 `let` 语句**之后**，
  写进逗号声明列表里是语法错误（会把整段动画打挂）。
- `claim` 脚本：覆盖层还在屏幕上时每 250 ms **重申一次占用**（主题收尾会
  `release()` 不带 id，会把别人的帧一起放掉）；退出淡出结束后再摘掉 `<html>`
  上的 `data-dsh-splash-transparent`，避免淡出过程中页面变底色。

验证（`D:\Develop\tools\mls-master-switch`）：

- `verify-splash-claim.js` 35/35（含新增：画布 alpha、底板蒙版、跳层、
  clamp 位置回归、内嵌 BOOT_SCRIPT 可解析、抢回被放掉的帧、淡出后清标记）。
- 在运行中的桌面端 DevTools 里直接重放修好的渲染器：画布四角 `0,0,0,0`、
  底板 `alpha 87`、金色球体/星场叠在桌面壁纸之上。
  对照图：改前 `tools\mls-master-switch\boot\boot-05-1876ms.png`（纯黑底），
  改后 `tools\mls-master-switch\final-look-b.png`（壁纸与图标清晰透出）。
- 注入行由宿主进程启动时构建，所以**必须重启桌面端才生效**：用
  `plugin_manager` 把 `include:splash` 关掉再打开能重建行，但桌面端走的是
  启动时缓存的那份（实测重载页面后仍是旧行），插件热重载不够。
- `patch-splash-transparency.cjs` 是幂等的补丁脚本，重跑只会报告 already patched。

## 2026-10-18（第二轮）· 球体再亮一点

透到壁纸之后，金色线框比原来压在自家黑底上时显得暗（线宽/透明度是照深色背景调的）。
`patch-splash-brightness.cjs` 把三档深度线的 alpha 从 `.34/.62/.92` 提到 `.40/.72/.98`，
光晕四层从 `.075/.034/.05/.019` 提到 `.088/.042/.062/.024`，泛光增益 `ne` 从 `.2` 到 `.26`
（约 +10~20%，梯度形状不动）。幂等，重跑只会报告 already patched。

同一轮还修了"动画旁边漏出工作区标题和按钮"：那不在 splash 里 —— 是 `visibility`
被**后代**用 `visibility: visible` 顶穿，改在主题的客户端样式表（见
`dsh-theme-mls-desktop` 的 CHANGELOG 0.4.9）。

> 注意：改主题的 `client.js` 之后，桌面端**必须重启** —— 壳在启动时把客户端 bundle
> 按内容哈希预打包，改了文件而页面又重载，会拿到 `plugins/??…client.js&rev=…` 的
> 404（表现为"应用无法启动或已意外停止 / 1 entry did not activate"）。重启即恢复。

## 2026-10-18（第三轮）· 收尾交叉淡出 + 去掉 logo 暗底

`patch-splash-handoff.cjs`（幂等）做了两件事：

1. **交接从"硬切"改成交叉淡出**。原来退出那一瞬间就 `release()`，应用整块跳出来，
   覆盖层之后才慢慢淡 —— 等于淡出盖在一个已经画好的界面上，读起来就是"啪"一下。
   现在 claim 脚本在交帧**之前**先给 `<html>` 打 `data-dsh-splash-handoff`，样式表用
   `@keyframes dsh-splash-app-in` 把应用子节点在同一个 `EXIT_MS` 里从 0 淡到 1；
   淡出结束（+520 ms 摘 `data-dsh-splash-transparent`、+640 ms 摘 handoff）才算完。
   顺带把 `EXIT_MS` 从 300 提到 400、把老式 `ease-in` 换成 `cubic-bezier(.4,0,.2,1)`，
   并把 boot 脚本里"淡出后移除节点"的 340 ms 提到 460 ms（原来 340 < 新时长会被截断）。
2. **logo 的暗底去掉**。那块 `rgba(11,11,14,α)` + 加深层的底板只在"动画自带背景"时
   有意义；透明模式下两层填充都跳过，只留金色角标。原来那条 `.32` 蒙版 clamp 随之删除。

验证：`verify-splash-claim.js` **42/42**（新增：交帧前已挂 handoff、淡出后两处标记都清、
`EXIT_MS=400`、缓动曲线、节点存活 460 ms、keyframes 与规则在位、底板两层被跳过、
没有残留的 clamp）。并在运行中的页面里把时长放大到 2.4 s 录了 26 帧：中间帧能同时看到
半透明的应用和覆盖层的金色线框，末帧干净回到应用 —— 确认是交叉淡出而不是跳变。

## 0.1.1（发布版）· 与 0.1.0 的差别

`package.json` 版本 `0.1.0` → `0.1.1`，**0.1.0 保持原样**（已安装的 pin 不受影响）。
另外：

- `@deepseek-ai/dsh-host-webserver` 的 peer 从精确 `0.2.0-rc.2` 放宽到
  `>=0.2.0-rc.2 <0.3.0`：原来那个精确钉法让 0.2.1-rc.2 上的安装被兼容性闸门挡住，
  只能靠"版本豁免"绕过（官方标注有崩溃/丢数据风险）。放宽之后可以直接装。
- `CHANGES.md` 进 `files`，随 tarball 一起发。
- 调查期间临时加的诊断探针（`/* DIAG-PROBE (temporary) */`，启动时把画布像素与
  分层栈 POST 到 `127.0.0.1:8791`）已从产物中删除，发布版不带它。

安装（DSh 桌面端 profile）：

```
dsh plugin --profile desktop add https://github.com/Oblivion-Ice/DSH-Arknight-Splash/raw/main/dsh-splash-0.1.1.tgz
```

