# DSH Splash — 桌面端启动动画插件

> DeepSeek Harness 桌面端的**品牌化启动动画**插件：主窗口一出现就是 DSH 品牌启动画面，运行时就绪后无缝交接给应用界面。

| | |
|---|---|
| 插件 ID | `dsh-splash` |
| 目标宿主 | DSH Desktop `0.2.0-rc.2`（`@deepseek-ai/dsh-desktop` / `dsh-desktop-host`） |
| 运行时 | Electron (Web GUI 渲染进程) + Node ≥ 20 |
| 技术栈 | TypeScript · Canvas 2D · Cordis 插件模型 |
| 状态 | 实现完成；本地与**真机**均验证通过（真机数据见下方"当前验证状态"与 [docs/06](docs/06-real-machine-checklist.md) §8）；验收第 1 项已按决定记为范围外 |

![启动画面预览](docs/preview.png)

> 上图为实现的真实渲染帧，来自 `node tools/preview.mjs && node tools/visual-check.mjs` 产出的文档在 headless Chromium 中 `canvas.toDataURL()` 的结果（`.preview/shots/preview.png`，即入场结束后的稳定态，1280×820）。不是设计稿。刷新方法：跑那两条命令，然后把 `timeline-default-5400ms.png` 复制到 `docs/preview.png`。

---

## ⚠️ 一个已确认的架构限制（请先读这一节）

对 `D:\Deepseek\resources\app.asar` 逐处取证后确认：**桌面端不经过 `renderIndexInjections`**。

| 步骤 | 行为 |
|---|---|
| `shell` 的 `serveWebDocument` | 只往 `<head>` 注入 `globalThis.__DSH_BOOT_READY__ = Promise.withResolvers()`；静态 `index.html` 就是 `<body><div id="root"></div></body>` |
| `dsh-desktop-host` | 把 `ctx.webServer.collectIndexInjections()` 经 `DESKTOP_IPC.boot` 交给页面 |
| 客户端 bundle 的 `hM(rows)` | 在 `dshDesktopBoot.ready()` resolve **之后**才应用行表；`html` 走 `document.body.insertAdjacentHTML('beforeend', …)` |

这不是实现缺陷，而是 `dsh-host-webserver` 的**明确设计**——它自己的文档注释写着"one table feeds two renderers: the served form renders rows into the index.html text, and a static worker deployment ships the same rows over its boot payload for a page-side interpreter"。桌面端是后者。

三个后果：

1. **覆盖层与铺底都不在文档首帧**。"窗口首帧为暗色、无浅色像素"（`prompt/01` §4.1.2 / 验收 1）**靠本插件的注入点无法达成**，需要上游在外壳侧修 —— 建议方案见 [`docs/02-architecture.md` §8 D4](docs/02-architecture.md)。
2. 本插件能做到的最优是：行表一应用就**同步绘制品牌首帧**，窗口的下一次合成即是覆盖层。为此 `renderer.start()` 绝不等 idle / 字体 / 图片。
3. 交接判据必须在**整棵文档子树**里找 `_boot_`（它挂在 `#root` 内），不能扫 `body.children`。实现已修正，并在挂 observer 时立即采样初态。完整取证链见 [`docs/03-design-spec.md` §9.1](docs/03-design-spec.md)。

除首帧铺底外，其余目标（品牌呈现、真实阶段反馈、无白屏交接、可访问性、可禁用、零外壳改动）均已达成。

### 关于"首帧铺底"的最后决定：**记为范围外**

**决定日期**：2026-10-14 · **决定内容**：验收第 1 项（窗口首帧为暗色、无浅色像素）**不纳入本插件的交付范围**。

**理由**：

1. **责任方不对**。缺口在外壳的文档服务路径（`shell/lib/main.js` 的 `serveWebDocument`），不在插件。本插件的注入点在任何部署形态下都晚于首帧，这是设计使然，改插件不可能解决。
2. **成本会转嫁给使用者**。走上游意味着本仓库单独不完整：必须连外壳补丁一起分发，且**每次 DSH 升级都要重打 `app.asar`**（升级会替换整个 asar）。插件不该要求用户承担这个。
3. **收益有限**。未满足的表现为"窗口 `show()` 到注入行落地之间白底闪一下"，时长取决于 host 启动速度。覆盖层一旦上屏即全程不透明并自带 `#151517` 底色，**交接期本身没有白屏**——缺的只是最前面那一小段。
4. **留证据、不隐瞒**。补丁草案保留在 [`docs/patches/d4-shell-first-frame.patch`](docs/patches/d4-shell-first-frame.patch)（上下文行已与真实的 `lib/main.js:7414` 逐字节比对通过），取证链保留在 [`docs/03-design-spec.md` §9.1](docs/03-design-spec.md)。问题交给正确的责任方，而不是消失。

**这个决定不等于"该项通过"**。它现在与将来都以"**未达成（范围外）**"记录，任何验收结论都不得把它算作通过。

**若日后改为走上游**：补丁已就绪，只需在 `serveWebDocument` 的 `<head>` 替换中加一段铺底样式；届时该项需要真机录屏确认后才能从"未达成"改为"通过"。

---

## 它做什么

DSH 桌面端现有的启动路径（实测，来源 `shell/lib/main.js`）：

```
app.whenReady()
  → spawn 内嵌 dsh runtime 子进程
  → 提前创建主 BrowserWindow（show: false，1280×820）
  → await reconcileBackend()
  → navigateMain("dsh-app://app/")   ← 静态 SPA dist
  → window.show()                    ← 此时文档已开始加载
  → 前端 bundle 加载 → 移除自带 _boot_ 遮罩 → 应用可用
```

期间用户只看到前端自带的极简 `_boot_` 遮罩（字标 `HARNESS` + 20px spinner + `Loading plugins…`）。

`dsh-splash` 在这段等待期填充一个有品牌感的画面：

1. **注入**：宿主侧通过 `webserver/index-inject` 向 `index.html` 的 `<head>` 推入样式行（先铺 DSH 暗色底，消除白闪），向 `<body>` 推入自包含的动画覆盖层。
2. **动画**：黑金暗场 + 星点光晕 → 金色不规则**凸包**线框球（正圆投影，`0.72u` 直径；**44 顶点 / 126 边**，轮廓最坏径向缺口 8.6%）持续运动：自转 `0.14 rad/s`、俯仰摆动 ±5.2°/7.5 s、半径呼吸 ±1%/5.2 s → 中央面板浮起（**金色细线**鲸鱼标记 + `DEEPSEEK` / `Harness`，四角括号而非圆角卡片）→ **两侧卡尺线从画面边缘一路合拢到球心**（`4200 ms`，两个箭头在正中合成 `><`）→ 真实阶段文案切换。
3. **交接**：以前端 `_boot_` 遮罩的移除为"应用可用"信号，**但退场不得早于首帧 + `minimumVisibleMs`（默认 5400 ms）**，随后覆盖层自毁（退出时长由 `EXIT_MS` 单一持有，见设计规格 §6）；带 `slow` / `failed` 兜底与 `prefers-reduced-motion` 降级。
4. **跳过**：覆盖层任意位置按下鼠标，或按 `Esc` / `Enter` / `Space`，立即淡出（不等地板），画面上常驻一行 `按 Esc 或点击任意位置跳过`。`config.skippable: false` 可整体关闭。见设计规格 §6.5。

### 为什么不是独立 splash 窗口

外壳在主窗口 `show()` 时其文档已经在加载（`main.js:12071-12089`），因此插件无法在窗口可见前绘制任何东西；而 `dsh-app://app/` 的 `index.html` 由 `dsh-host-webserver` 按注入行表渲染，**是唯一在主窗口首帧就已存在的插件可达表面**。详见 [docs/02-architecture.md](docs/02-architecture.md) §1–§2。

---

## 配置

配置来自 profile 的 `cordis.patch.yml`（本仓库根部的 `cordis.patch.yml` 是插件自带的那一层）。键名、默认值与取值区间见 `src/host/config.ts`。插件另外导出一个 Schemastery `Config`，因此这些项会出现在 **DSH 自己的设置界面**里，改动由 DSH 持久化回 profile 的 patch 文件。

> **`minimumVisibleMs` 是"最少停留多久才准退场"，不是"入场时长"。** 入场时间轴按自己的节奏跑完（`ENTRANCE_END_MS`，当前 **4900 ms**——卡尺线合拢到球心是最长的一条轨），退场最早在首帧 + 该值（默认 **5400 ms**）发生，其间 500 ms 定格；设为 `0` 即恢复"应用一就绪就退场"。
>
> 5.4 秒对开屏来说是长的，所以同一个默认值配了出口：`skippable`（默认 `true`）允许用户点击或按 `Esc` 立即跳过，**跳过不排队等地板**。两者是同一轮加的，理由写在设计规格 §6.5。
>
> patch 行会**整块替换**匹配行的 `config`，所以本仓库根部的 `cordis.patch.yml` 只要与 `DEFAULT_CONFIG` 不一致，它就是在运行时生效的那一份。这个默认值曾因此长期停在旧值——代码改成 2600 而 YAML 仍是 900，插件"改了却没生效"。`test/injection.test.ts` 现在逐个字段比对键**与值**，不再只比对键名。

**namespace 提醒**：设置命名空间是 profile 条目的 **`id`**，本仓库是 **`splash`**；包名 `dsh-splash` 是另一个字段，两者不能混用（依据 `dsh-settings/lib/index.js:505`，找不到即抛 `No configurable plugin entry`）。

> **⚠️ 手写配置写错类型会怎样**：因为有了 schema，配置会在插件启动**之前**被校验（`cordis/lib/index.js:956-962`）。**类型写错不会回落默认值，而是让本插件直接失活**——启动动画不出现，**设置界面里的这一项也会一并消失**，只能手改配置文件修回来。宿主本身照常启动，并在 stderr 留下精确到字段的日志：
>
> ```
> dsh: warning: 1 entry did not activate
> splash (dsh-splash): ValidationError: invalid config:
>   - $.minimumVisibleMs expected number but got abc (at minimumVisibleMs)
> ```
>
> 这是为了让设置界面存在而**明确接受**的取舍（`prompt/01` §3.5 原本要求"畸形输入回落默认值"）。取值区间与默认值都有断言锁定，保证**界面自己能产出的值一定被接受**，所以只有手写配置才会踩到。详见 [docs/02-architecture.md](docs/02-architecture.md) §5.3。

---

## 文档

| 文档 | 内容 |
|---|---|
| [docs/01-overview.md](docs/01-overview.md) | 目标、范围、非目标、术语、成功标准、约束与假设 |
| [docs/02-architecture.md](docs/02-architecture.md) | 取证结论、架构决策、分层、生命周期、契约、降级路线、待验证项 |
| [docs/03-design-spec.md](docs/03-design-spec.md) | 视觉规格：逐帧实测的几何、配色 token、动效时间轴、交接规格、实测性能 |
| [docs/04-implementation-plan.md](docs/04-implementation-plan.md) | M0–M6 里程碑、任务拆分、验收实测表、风险登记、工作量 |
| [docs/05-review-report.md](docs/05-review-report.md) | **独立对抗性评审报告**（评审者原始结论 + 我方复核与逐条处置，含 10 项破坏性测试结果） |
| [docs/06-real-machine-checklist.md](docs/06-real-machine-checklist.md) | 真机验证清单（本沙箱无法覆盖的 8 组检查 + 报告模板） |
| [docs/patches/d4-shell-first-frame.patch](docs/patches/d4-shell-first-frame.patch) | 上游补丁草案：让主窗口首帧即为 DSH 暗色底（**首帧白闪的唯一解法**） |
| [prompt/01-implementation-prompt.md](prompt/01-implementation-prompt.md) | **可交付 prompt**：交给编码 agent 直接执行 |
| [prompt/02-review-prompt.md](prompt/02-review-prompt.md) | 对抗性代码评审 prompt（含 10 项破坏性测试） |
| [prompt/03-variant-prompts.md](prompt/03-variant-prompts.md) | 8 个变体 prompt（降级路线、范围裁剪、专项） |

---

## 目录结构

```
dsh-splash/
├─ package.json                 # 插件包声明（含 dsh 段）
├─ cordis.patch.yml             # bundle patch 的 insert 行
├─ tsconfig.json                # strict + noUncheckedIndexedAccess + exactOptionalPropertyTypes
├─ build.mjs                    # boot script + version 戳 + .d.ts + host ESM + client 信封
├─ build-tests.mjs              # 用 esbuild 打包测试（解决 .js 说明符）
├─ generated/
│  └─ boot-script.ts            # 由 build.mjs 从 src/render/boot.ts 打包生成（git-ignore）
├─ tools/
│  ├─ preview.mjs               # 用真实 renderIndexInjections 生成 index.html（并内联品牌字体）
│  ├─ visual-check.mjs          # 构图断言 + 时间轴抽帧 + 线框密度 + 单帧成本
│  └─ real-machine/             # 真机 harness（真实 dsh 宿主 + 真实 Chromium，见 tools/README.md）
├─ src/
│  ├─ shared/
│  │  └─ protocol.ts            # host 与注入层的字符串契约、阶段文案与阶段名
│  ├─ host/
│  │  ├─ index.ts               # apply(ctx, config)：注册 index-inject 行
│  │  ├─ config.ts              # Config / DEFAULT_* / resolveConfig / resolveTheme
│  │  ├─ injection.ts           # 组装注入行（global ×2 + style + html + script）
│  │  ├─ markup.ts              # 覆盖层 DOM
│  │  ├─ stylesheet.ts          # 注入样式（铺底 + 定位）
│  │  └─ version.ts             # 由 build.mjs 按 package.json 重写的版本戳
│  ├─ render/
│  │  ├─ brand.ts               # 鲸鱼标记路径（与 FISH_LOGO_PATH 同源）
│  │  ├─ geometry.ts            # 不规则线框球几何（球面点集的凸包）
│  │  ├─ orbit.ts               # 球体外围的极暗轨道环
│  │  ├─ layout.ts              # 构图尺寸表（逐帧实测，见 §1）
│  │  ├─ frame.ts               # 每帧状态视图（绘制模块的入参）
│  │  ├─ background.ts          # 底色渐变、顶部光、呼吸光晕
│  │  ├─ sphere.ts              # 线框投影、深度分桶、节点、辉光
│  │  ├─ plate.ts               # 中央面板与鲸鱼/字标锁定组
│  │  ├─ chrome.ts              # 卡尺线（含箭头）、状态行、跳过提示、角标
│  │  ├─ stars.ts               # 三档星野（预渲染 alpha 图，加法混合）
│  │  ├─ tokens.ts              # 只读读取 --dsw-* / --dsh-splash-* 并解析
│  │  ├─ renderer.ts            # 绘制、入场时间轴、零分配帧
│  │  └─ boot.ts                # 注入的引导脚本（打包成 IIFE）
│  └─ client/
│     └─ index.ts               # dsh.client 半边（slots）
├─ test/                        # node:test（config / geometry / injection / boot）
└─ docs/ · prompt/
```

---

## 安装

### 从 GitHub 安装（DSH profile）

把这行加进 `$DSH_HOME/profiles/<name>/cordis.patch.yml`，然后让 DSH 装上包本体：

```powershell
# 1) 在 profile 里安装（git 源会触发 package.json 的 prepare，自动构建 dist/）
cd $env:USERPROFILE\.dsh\profiles\desktop
node $pnpm add github:<你的账号>/dsh-splash

# 2) 声明成 bundle 条目
```

```yaml
- insert:
    - id: splash
      name: 'dsh-splash'
      config:
        enabled: true
        minimumVisibleMs: 5400
        slowThresholdMs: 8000
        maximumWaitMs: 60000
        bootDetectMs: 1500
        reducedMotion: auto
        skippable: true
```

> `dist/` 与 `generated/` 都在 `.gitignore` 里，所以仓库里没有构建产物；`package.json` 的 `prepare` 脚本负责在安装时构建它们。这也是**不要把 `dist/` 提交进去**的原因——它会在每次 clone、每次安装时被重新生成，提交它只会制造两份可能不一致的真相。

### 从 tarball 安装（离线 / 指定版本）

```powershell
node $pnpm pack --pack-destination release      # 产出 release/dsh-splash-0.1.0.tgz
node $pnpm add ./release/dsh-splash-0.1.0.tgz
```

---

## 发布到 GitHub

本机（2026-10-15 核对）**没有安装 git**，也没有 `gh`，仓库里没有 `.git`，因此下面这些命令需要你先装一次 git。装完**重开终端**（PATH 才会更新），`winget` 已可用：

```powershell
winget install --id Git.Git -e --source winget
git --version
git config --global user.name  "Your Name"
git config --global user.email "you@example.com"
```

### 1. 在 GitHub 上建一个**空**仓库

名称 `dsh-splash`，**不要**勾选 "Add a README / .gitignore / license"——本地已经有这三个，勾了会产生一次无谓的合并。

### 2. 首次提交与推送

```powershell
cd D:\Develop\dsh-splash
git init -b main
git add -A
git status                      # ← 先看清楚要提交什么，见下方"发布前检查"
git commit -m "dsh-splash 0.1.0: branded startup overlay for DSH Desktop"
git remote add origin https://github.com/<你的账号>/dsh-splash.git
git push -u origin main
```

HTTPS 推送时会弹窗要求登录：Git for Windows 自带 Credential Manager，浏览器授权一次即可；也可以改用 **Personal Access Token**（fine-grained，权限只需 `Contents: Read and write`）当密码。装了 `gh` 的话 `gh auth login` 更省事。

### 3. 打 tag 并在 Release 里附上 tarball

```powershell
node $pnpm check                                        # 先把总闸跑绿
node $pnpm pack --pack-destination release              # release/dsh-splash-0.1.0.tgz
git tag -a v0.1.0 -m "dsh-splash 0.1.0"
git push origin v0.1.0
```

然后在 GitHub 的 Releases 页面 "Draft a new release" → 选 `v0.1.0` → 把 `release\dsh-splash-0.1.0.tgz` 拖进附件区。

### 发布前检查

`git status` 之后应该**只**看到源码、文档与配置，**不应该**出现下面这些（都已在 `.gitignore` 里）：

| 不该出现 | 为什么 |
|---|---|
| `node_modules/`、`dist/`、`generated/`、`.test-dist/` | 构建产物与依赖，安装时重新生成 |
| `.preview/` | 视觉 harness 的抽帧与报告 |
| **`.real-machine/`** | **隔离 host 的 scratch：里面的 `host.json` 与 probe 日志带着一个真实的 `?token=`**。它被 ignore 了，但这是整个仓库里唯一一处曾经存在凭据的地方，删掉它也无妨 |
| `release/` | 打包产物，属于 Release 附件而不是源码 |

另外两件发布前该定的事：

- **`LICENSE` 的著作权人**。`package.json` 里写的是 `"license": "MIT"`，仓库里的 `LICENSE` 按此补了标准 MIT 文本，署名一行目前是 `dsh-splash contributors`——换成你自己的名字或组织。
- **`package.json` 的 `repository` 字段**。填上之后 npm/GitHub 会互相链接，也不是必须：

  ```powershell
  node $pnpm pkg set repository="github:<你的账号>/dsh-splash" homepage="https://github.com/<你的账号>/dsh-splash"
  ```

---

## 开发

`node` / `pnpm` 未在 PATH 上时使用 DSH 自带的运行时：

```powershell
$env:PATH = "C:\Users\MR\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\node\bin;$env:PATH"
$pnpm = "C:\Users\MR\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\pnpm\bin\pnpm.mjs"

node $pnpm install                # 首次
node $pnpm build                  # dist/host、dist/client、generated/boot-script.ts、.d.ts
node $pnpm typecheck              # build.mjs --only=generate && tsc --noEmit（strict + noUncheckedIndexedAccess + exactOptionalPropertyTypes）
node $pnpm test                   # esbuild 打包后在 node:test 下运行（项数见下方"当前验证状态"表）

# 端到端：用真实的 renderIndexInjections 生成 DSH 会实际提供的 index.html
node tools/preview.mjs --width 1280 --height 820
# 构图 + 时间轴抽帧 + 性能（写入 .preview/shots/ 与 .preview/visual-report.json）
node tools/visual-check.mjs
node tools/visual-check.mjs --mesh --verts --perf 240   # 线框密度 / 顶点数对照表 + 单帧绘制成本
node tools/visual-check.mjs --only minimum           # 只跑最小尺寸

node $pnpm check                  # 确定性总闸：generate + build + typecheck + 测试 + preview + visual-check
node $pnpm check:real-machine     # 真机 harness（真实 dsh 宿主 + 真实 Chrome），不属于 check
```

> `typecheck` 先跑 `build.mjs --only=generate` 再跑 `tsc --noEmit`，因为 `generated/` 是 git-ignore 的构建产物：全新 clone 上没有它，`src/host/injection.ts` 的 import 解析不到，裸 `tsc --noEmit` 会直接失败。`--only=generate` 只执行 boot script 这一步就退出，不做完整构建。

> `check` 是**确定性总闸**，任何机器上都能跑（无需显示器、无需安装 DSH）：`build.mjs --only=generate && build.mjs && tsc --noEmit && build-tests.mjs && node --test && tools/preview.mjs && tools/visual-check.mjs`，是 CI 该跑内容的超集。它需要 Node、`node_modules`（先 `install`）和 Chrome（`tools/visual-check.mjs` 默认走 `C:/Program Files/Google/Chrome/Application/chrome.exe`，可用 `--chrome` 改）。
>
> `check:real-machine` 运行 `tools/real-machine/matrix.mjs`：真实 `dsh` 宿主 + 真实 Chromium 的 13 个变体矩阵，因此**不放进 `check`**（会起进程、开浏览器、需要本机的 DSH Desktop 安装，每个变体约 40–90 s）。它有一次性前置条件：`tools/real-machine/README.md` §3 描述的**隔离 profile**（独立 `DSH_HOME`，不碰你自己的 `%USERPROFILE%\.dsh`）；按 §3 建好后用 `node $pnpm check:real-machine -- --home <isolated-home>`（或 `--scratch <dir>`）指向它。

> 上面用 `node $pnpm <script>` 而不是 `pnpm <script>`，只是为了不依赖 `pnpm` 在 PATH 上；两者等价。
>
> 仓库里有一个 [`pnpm-workspace.yaml`](pnpm-workspace.yaml)，只做一件事：用 `allowBuilds` 在**本项目内**批准 esbuild 的安装期构建脚本。本机的**用户级** npmrc 把 `allowBuilds.esbuild` 写成了占位字符串 `"set this to true or false"`（永远不为真），于是 esbuild 的 postinstall 从不执行、`pnpm install` 以 `ERR_PNPM_IGNORED_BUILDS` 退出，pnpm 的运行前依赖检查又把这个失败放大成"所有脚本都跑不了"。项目级设置覆盖它即可，且不改动全局配置。

> `tools/visual-check.mjs` 通过 loopback HTTP 提供 `.preview/`，不是 `file://`：Chrome 给每个 `file://` 文档一个不透明源，页面读不到自己的测量值。它也不用 `--screenshot` 抓动画——headless Chrome 的虚拟时钟**不驱动 `requestAnimationFrame`**，那样只会拍到第 0 帧（本项目踩过这个坑，六张"动画"截图全是空背景）。时间轴改用 `renderer.renderAt(elapsedMs)` 确定性渲染，画面以 `canvas.toDataURL()` 从页面里取出。

在 DSH profile 中启用（`$DSH_HOME/profiles/<name>/cordis.patch.yml`）：

```yaml
- id: splash
  config:
    enabled: true
    minimumVisibleMs: 5400
    slowThresholdMs: 8000
    maximumWaitMs: 60000
    bootDetectMs: 1500
    reducedMotion: auto
    skippable: true
```

---

## 当前验证状态

**已在本地实测通过**（复现命令见上方"开发"）：

| 项 | 结果 |
|---|---|
| 类型检查 | `tsc --noEmit` 零错误（`strict` + `noUncheckedIndexedAccess` + `exactOptionalPropertyTypes`） |
| 单元测试 | **122 / 122 通过**（9 个测试文件）。含 D1「`failed` 终态」、D2「退出时长单一定义」、地板与入场的关系、**四条入场曲线无过冲且浅入浅出**、**跳过的三条不变式**（抢在地板之前、不声称 `ready`、`failed` 不可跳）、`cordis.patch.yml` 与 `DEFAULT_CONFIG` 的**逐字段同值**校验、设置 schema 与活配置、以及客户端半边的定点回归。**测试总数只在本表维护**——其余文档一律引用此处，不再各自复述，因为此前它同时写在四处、每加一个测试就要改四遍，并且出现过分解加起来不等于总数的情况 |
| 构建产物 | 自包含 boot script 约 31 KiB；host ESM 导出 `apply` / `name` / `Config` 并附 9 个 `.d.ts`；client 为 `window.__ModuleLoader__.load({id, factory})` 信封，**在构建期按加载器的真实契约执行并验证**（`assertClientEnvelope`），且另有一条断言保证 React 被外部化、未被误打包进产物 |
| 注入契约 | 5 行 `[global, global, style, html, script]` 经 `@deepseek-ai/dsh-host-webserver` 的**真实** `renderIndexInjections` 渲染成功 |
| 交接状态机 | `test/boot.test.ts` 的 28 项断言，含**真实 DOM 形态**（`_boot_` 位于 `#root` 内且先于覆盖层存在）：初态采样、移除即交接、**地板把退场推迟到首帧 + `minimumVisibleMs`**、`0` 地板立即退场、**跳过抢在地板之前且不声称 `ready`**、`failed` 不可跳、`slow`/`failed`、兜底链、异常自删、teardown 幂等与监听器回收 |
| 端到端渲染 | `.preview/shots/` 下 5 个视口 × 8 个时刻的确定性抽帧；构图、**卡尺合拢到正中**（`ruleTipDrawnAt === width / 2`）、参考比、无障碍属性、标题栏避让、角标与水平线读数位置均由 harness 断言 |
| 单帧绘制成本 | `draw()` **中位 0.30 ms / p95 0.50 ms** @1080p、0.30 / 0.60 @1440p（headless 软件光栅，126 边）。判定用中位与 p95 而不是均值，理由与实测的停顿分布见设计规格 §11 |

**已在真机实测通过**（隔离 profile + 真实 `dsh` 宿主 + 真实 Chromium；完整数据与复现方法见 [docs/06-real-machine-checklist.md](docs/06-real-machine-checklist.md) §8）：

| 项 | 实测 |
|---|---|
| 插件装载 | 服务出的 `index.html` 含全部 5 行；`__DSH_SPLASH_BOOT_ERROR__` 恒为 null；宿主 stderr 无「entry did not activate」 |
| 交接判据 | 由观察 `_boot_` 移除驱动 —— `exitAt` 与移除时刻相差 **≤0.2 ms**，1500 ms 兜底从未被使用 |
| 退出耗时 | **343.0 ms**（≤ 验收第 4 项的 350 ms）。修正前为 360.6–368.0 ms，即那时该项**本就不合格** |
| 停留时长 | 首帧 → 退场 = **`minimumVisibleMs`**（默认 **5400 ms**），而不是"应用一就绪就退场"。修正前真机是 **890 ms**：入场时间轴长 1420 ms，所以面板与文字**从未到达满不透明度**就被淡出。该值现在真的生效（此前那份生效的 YAML 停在旧值 900），可由设置界面实时改。卡尺合拢到球心后总时长 5400 ms，其中 **4900 ms 在运动**、只有 500 ms 定格；实测在屏 **5726 ms** |
| 卡尺真的合拢到球心 | 由页面自己的 `requestAnimationFrame` 时钟逐帧采样左臂箭头的 x：`tipArrivedAt = 4803 ms`，与 `easeRule` 的解析解相差 **5 ms**；此后直到拆除一直停在 `640 = 1280 / 2`，全程**单调不减**（过冲会表现为回头，实测 0 次） |
| 跳过 | 用 `Input.dispatchKeyEvent` / `dispatchMouseEvent` 走浏览器真实输入管线：`Escape` 在首帧 + 1511 ms 触发，**3 ms 后**开始退场、371 ms 后节点移除。退场后的 `data-phase` 是 `runtime`，**不是 `ready`**；`aria-keyshortcuts=Escape` 与提示文案均在屏 |
| 稳态帧率 | **300.7 fps @1920×1080**（覆盖层在屏；面板本身 2560×1600 @300 Hz） |
| 真机单帧成本 | 均值 **0.34 ms** @126 边（44 顶点，比 30 顶点时多 50% 的边，均值 +10%）、最慢帧 4.4–6.7 ms |
| 页面内白闪 | **0 个亮帧**，逐帧亮度首值 18–19/255 |
| 五种视口 + DPI | 1280×820 / 1920×1080 / 2560×1440 / 520×600 / 3440×1440 全部不越界；dPR 2.5 按设计钳到 2（画布 3840×2160） |
| 球体垂直居中 | 五种视口断言 `centerY / height = 0.50`；1080p 逐像素球心 `542 / 1080`，上下留白各 `151 px`（改前 `0.56 h` 是 `216 / 86`） |
| `slow` / `failed` / `disabled` | 三条路径均实测到达；「重新加载」按钮点击后真的重载（`timeOrigin` 改变）；修正后 `failed` **确认是终态**（读取时刻 6000 ms 时仍为 `failed`，4000 ms 的 `session` 步骤未覆盖） |
| reduced-motion | `spin` 恒为 `REST_ROT_Y` 且阶段文案仍推进；`never` 在 OS 请求降级时仍动画 |
| 无障碍（覆盖层） | `role=status` / `aria-live=polite` / `aria-busy=true` 在无障碍树中命中 |
| 客户端半边 | 客户端入口激活（构建断言 + 真机）；控制台零错误、零未捕获异常 |
| **席位实时区域** | 交接后 2000 / 4000 ms 两次采样均在无障碍树中：`role=status`、`live=polite`、`atomic=true`、`ignored=false`，并含 `StaticText`「启动完成，可以开始使用」；`overlayPresent=false` 时区域仍在 |
| 设置架构 | schema 被宿主识别、按条目 `splash` 校验；合法配置 → 插件激活；**畸形配置 → 宿主照常启动**，插件失活并在 stderr 留下精确到字段的 `ValidationError` |

**尚未验证或无法验证**：

| 项 | 说明 |
|---|---|
| **窗口首帧为暗色、无浅色像素** | **无法由本插件达成**，见上方限制说明；需上游 D4。真机已证明**页面内**无白闪，剩余的白来自页面出现之前的 OS 窗口背景 |
| 桌面 IPC 注入路径 | 真机跑的是 HTTP 服务路径（`renderIndexInjections`）。桌面端经 `dshDesktopBoot.ready()` → `hM(rows)` 投递，两条路径共享 `collectIndexInjections()` 但投递方式不同，**未实测**（本机无法另起桌面实例：端口 19387 写死且冲突即致命） |
| **屏幕阅读器实际朗读** | 只证明了实时区域**在 Chromium 无障碍树中**、未被忽略、角色与 `aria-live` 正确；**没有跑过 NVDA / Narrator / VoiceOver**，不能据此声称"确实会朗读" |
| **`#root[inert]` 的时限与后果** | shell 没有打开会话时 `#root` 带 `inert`，而 `shell.overlay` 渲染在 `#root` 内 —— 因此**席位自身的子树无法承载无障碍内容**（CDP 实测 `role:none, ignored:true`）。本插件只能把区域挂到 `<body>` 并让席位负责调度。`inert` 何时解除（开一次会话之后？）**未验证** |
| 客户端半边的 `enabled:false` 变体 | 未在真机跑过；客户端 bundle 只在插件行激活时才被加载 |
| 席位在 reduced-motion 下 | 它本身没有动画可供降级，只有单测断言"不存在动画" |
| **`apply` 在真机上执行两次** | 客户端 `apply` 于 343 ms 与 521 ms 各跑一次（已做幂等保护、`register` 幂等）。**根因未查** |
| 内存增量 ≤ 8 MB | 只量到绝对堆占用（6.5–28.4 MB）；增量需要基线窗口 |
| 冷启动 enabled/disabled 差值 | 需要三次桌面冷启动对比 |
| 多显示器拖动、真实 DPI 缩放下的清晰度 | 需要真实桌面窗口 |

---

## 许可

MIT
